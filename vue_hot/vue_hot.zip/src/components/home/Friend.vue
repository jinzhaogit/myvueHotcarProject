<template>
    <div class="section">

    </div>
</template>
<script>
    export default {
        name: 'home',
        data(){
            return{

            }
        },
        methods:{

        }
    }
</script>
<style>

</style>